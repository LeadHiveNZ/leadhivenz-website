ONSHORE AIR · LOGO CONCEPT 2: HORIZON
Concept files · 26 October 2026 · prepared by LeadHive AU

COLOURS
  Ink Navy        #0C1C45   RGB 12 28 69
  Sun Gold        #F4B23E   RGB 244 178 62
  Sea Blue        #2A7FD4   RGB 42 127 212
  White           #FFFFFF   RGB 255 255 255
  Print: ask the printer to match these hex values on your stock (CMYK not yet proofed).

FONT
  Name: Sora Bold. Descriptor: Sora SemiBold. Google Fonts, SIL Open Font Licence.
  All lettering is converted to outlines, so no font needs to be installed.

WHICH FILE FOR WHAT
  Van wrap / signs ........... horizontal.svg (vector, scale to any size)
  One-colour vinyl ........... horizontal-mono-navy.svg / horizontal-mono-white.svg
  Embroidery (polos, caps) ... mono-white.svg on navy shirts, mono-navy.svg on light shirts
  Google / Facebook picture .. png/icon-app-512.png
  Website header ............. horizontal-on-navy.svg (computer), horizontal-compact-on-navy.svg (phone)
  Browser tab (favicon) ...... favicon.svg + png/icon-32.png + png/icon-app-180.png (iPhone)
  Invoices / email ........... horizontal.svg, or png/horizontal@2x.png
  Business cards ............. primary-stacked.svg (front), icon-on-navy.svg (back)
  On navy backgrounds ........ any file ending in -on-navy, or the mono-white files

SMALLEST SIZES
  Horizontal, with descriptor   240 px on screen / 60 mm in print
  Compact horizontal            120 px / 30 mm
  Stacked logo                  120 px / 25 mm
  Embroidery (mono files)       60 mm wide on a polo chest, 50 mm on a cap
  Icon                          64 px / 8 mm (favicon.svg is drawn for 16-48 px)

CLEAR SPACE
  Leave a gap equal to the height of the capital letters in ONSHORE on every side.

DON'T recolour, stretch, add shadows or outlines, or put the colour logo on a busy photo.
