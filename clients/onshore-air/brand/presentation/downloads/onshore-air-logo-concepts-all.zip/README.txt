ONSHORE AIR · LOGO CONCEPTS (ALL THREE)
Round 2 · 26 October 2026 · prepared by LeadHive AU

Concept 1, Evolution (recommended) · Concept 2, Horizon · Concept 3, Monogram
Each folder has its own README.txt with colours, font, sizes and which file to use.
